<template>
  <div class="signup">
    <h2>Patient Signup</h2>
    <form @submit.prevent="signup">
      <input type="text" v-model="name" placeholder="Name" required />
      <input type="email" v-model="email" placeholder="Email" required />
      <input type="password" v-model="password" placeholder="Password" required />
      <button type="submit">Signup</button>
    </form>
    <p>{{ message }}</p>
  </div>
</template>

<script>
import api from '../axios'
import { useRouter } from 'vue-router'

export default {
  data() {
    return {
      name: '',
      email: '',
      password: '',
      message: ''
    }
  },
  setup() {
    const router = useRouter()
    return { router }
  },
  methods: {
    async signup() {
      try {
        const res = await api.post('/auth/patient/signup', {
          name: this.name,
          email: this.email,
          password: this.password
        })
        this.message = res.data.message
        this.router.push('/patient-login')
      } catch (err) {
        this.message = err.response.data.message
      }
    }
  }
}
</script>
