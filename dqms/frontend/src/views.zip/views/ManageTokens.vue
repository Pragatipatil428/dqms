<template>
  <div class="min-h-screen bg-gray-50 p-6">
    <h1 class="text-3xl font-extrabold text-center mb-8 text-indigo-700">🛠 Manage Tokens</h1>

    <!-- Normal Token Requests -->
    <div v-if="normalTokens.length > 0" class="mb-8">
      <h2 class="text-2xl font-bold mb-4 text-indigo-800">Normal Token Requests</h2>
      <div class="grid md:grid-cols-2 gap-6">
        <div
          v-for="token in normalTokens"
          :key="token.token_number"
          :class="token.status === 'completed' ? 'bg-green-100 shadow-lg rounded-2xl p-6 hover:shadow-indigo-300 transition-shadow' : 'bg-white shadow-lg rounded-2xl p-6 hover:shadow-indigo-300 transition-shadow flex flex-col'"
        >
          <h3 class="text-xl font-semibold text-indigo-900 mb-2">Token #{{ token.token_number }}</h3>
          <p class="text-indigo-700 mb-1">
            Patient: <span class="font-medium">{{ token.patient_name }}</span>
          </p>
          <p class="text-indigo-600 mb-3">Time Slot: {{ token.time_slot }}</p>
          <p v-if="token.status === 'completed'" class="text-sm text-green-600 font-medium">Status: Completed</p>

          <!-- Actions -->
          <div v-if="token.status !== 'completed'" class="flex gap-2 mt-auto">
            <button
              @click="updateStatus(token.token_number, 'completed')"
              class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition"
              title="Mark as Completed"
            >
              Complete
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Scheduled Token Requests -->
    <div v-if="scheduledTokens.length > 0" class="mb-8">
      <h2 class="text-2xl font-bold mb-4 text-indigo-800">Scheduled Token Requests</h2>
      <div class="grid md:grid-cols-2 gap-6">
        <div
          v-for="token in scheduledTokens"
          :key="token.token_number"
          :class="token.status === 'completed' ? 'bg-green-100 shadow-lg rounded-2xl p-6 hover:shadow-indigo-300 transition-shadow' : 'bg-white shadow-lg rounded-2xl p-6 hover:shadow-indigo-300 transition-shadow flex flex-col'"
        >
          <h3 class="text-xl font-semibold text-indigo-900 mb-2">Token #{{ token.token_number }}</h3>
          <p class="text-indigo-700 mb-1">
            Patient: <span class="font-medium">{{ token.patient_name }}</span>
          </p>
          <p class="text-indigo-600 mb-3">Time Slot: {{ token.time_slot }}</p>
          <p v-if="token.status === 'completed'" class="text-sm text-green-600 font-medium">Status: Completed</p>

          <!-- Actions -->
          <div v-if="token.status !== 'completed'" class="flex gap-2 mt-auto">
            <button
              @click="updateStatus(token.token_number, 'completed')"
              class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition"
              title="Mark as Completed"
            >
              Complete
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Completed Tokens -->
    <div v-if="completedTokens.length > 0" class="mb-8">
      <h2 class="text-2xl font-bold mb-4 text-indigo-800">Completed Tokens ({{ completedTokens.length }})</h2>
      <div class="grid md:grid-cols-2 gap-6">
        <div
          v-for="token in completedTokens"
          :key="token.token_number"
          class="bg-green-100 shadow-lg rounded-2xl p-6 hover:shadow-indigo-300 transition-shadow"
        >
          <h3 class="text-xl font-semibold text-indigo-900 mb-2">Token #{{ token.token_number }}</h3>
          <p class="text-indigo-700 mb-1">
            Patient: <span class="font-medium">{{ token.patient_name }}</span>
          </p>
          <p class="text-indigo-600">Time Slot: {{ token.time_slot }}</p>
          <p class="text-sm text-green-600 font-medium">Status: Completed</p>
        </div>
      </div>
    </div>

    <!-- No Tokens -->
    <div v-if="tokens.length === 0" class="text-center mt-8">
      <p class="text-indigo-600 text-lg">No token requests for today.</p>
    </div>
  </div>
</template>

<script>
import api from "../axios"
import { useAuthStore } from "../store/auth"

export default {
  data() {
    return {
      tokens: []
    }
  },
  setup() {
    const authStore = useAuthStore()
    return { authStore }
  },
  computed: {
    normalTokens() {
      return this.tokens.filter(token => token.slot_type === 'normal' && token.status !== 'completed').sort((a, b) => a.token_number - b.token_number)
    },
    scheduledTokens() {
      return this.tokens.filter(token => token.slot_type === 'scheduled' && token.status !== 'completed').sort((a, b) => a.token_number - b.token_number)
    },
    completedTokens() {
      return this.tokens.filter(token => token.status === 'completed').sort((a, b) => a.token_number - b.token_number)
    }
  },
  async created() {
    await this.fetchTokens()
  },
  methods: {
    async fetchTokens() {
      try {
        const res = await api.get(`/hospitals/token-requests/${this.authStore.user.id}`)
        this.tokens = res.data
      } catch (err) {
        console.error("Error fetching tokens", err)
      }
    },
    async updateStatus(tokenNumber, status) {
      try {
        await api.post(`/hospitals/update-token-status`, {
          hospital_id: this.authStore.user.id,
          token_number: tokenNumber,
          status: status
        })
        // Refresh list after update
        await this.fetchTokens()
      } catch (err) {
        console.error("Error updating token", err)
      }
    }
  }
}
</script>
