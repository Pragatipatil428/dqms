<template>
  <div class="min-h-screen bg-gray-50 p-6">
    <h1 class="text-3xl font-extrabold text-center mb-8 text-indigo-700">📋 My Tokens</h1>

    <!-- Normal Tokens -->
    <div v-if="normalTokens.length > 0" class="mb-8">
      <h2 class="text-2xl font-bold mb-4 text-indigo-800">Normal Tokens</h2>
      <div class="grid md:grid-cols-2 gap-6">
        <div
          v-for="token in normalTokens"
          :key="token.token_number"
          class="bg-white shadow-lg rounded-2xl p-6 hover:shadow-indigo-300 transition-shadow"
        >
          <h3 class="text-xl font-semibold text-indigo-900 mb-2">Token #{{ token.token_number }}</h3>
          <p class="text-indigo-700 mb-1">
            Hospital: <span class="font-medium">{{ token.hospital_name }}</span>
          </p>
          <p class="text-indigo-600 mb-1">Date: {{ formatDate(token.date) }}</p>
          <p class="text-indigo-600 mb-1">Time Slot: {{ token.time_slot }}</p>
          <p class="text-sm text-indigo-500">Status: <span class="font-medium capitalize">{{ token.status || 'Pending' }}</span></p>
          <div v-if="isToday(token.date)">
            <p v-if="queueInfo[token.hospital_id] && queueInfo[token.hospital_id].running_token" class="text-sm text-green-600">
              Currently Running: Token #{{ queueInfo[token.hospital_id].running_token.token_number }} at {{ queueInfo[token.hospital_id].running_token.time_slot }}
            </p>
            <p v-if="tokenPosition[token.token_number]" class="text-sm text-blue-600">
              {{ tokenPosition[token.token_number].ahead }} tokens ahead — Estimated time: {{ tokenPosition[token.token_number].estimated_time }}
            </p>
          </div>
        </div>
      </div>
    </div>

    <!-- Scheduled Tokens -->
    <div v-if="scheduledTokens.length > 0" class="mb-8">
      <h2 class="text-2xl font-bold mb-4 text-indigo-800">Scheduled Tokens</h2>
      <div class="grid md:grid-cols-2 gap-6">
        <div
          v-for="token in scheduledTokens"
          :key="token.token_number"
          class="bg-white shadow-lg rounded-2xl p-6 hover:shadow-indigo-300 transition-shadow"
        >
          <h3 class="text-xl font-semibold text-indigo-900 mb-2">Token #{{ token.token_number }}</h3>
          <p class="text-indigo-700 mb-1">
            Hospital: <span class="font-medium">{{ token.hospital_name }}</span>
          </p>
          <p class="text-indigo-600 mb-1">Date: {{ formatDate(token.date) }}</p>
          <p class="text-indigo-600 mb-1">Time Slot: {{ token.time_slot }}</p>
          <p class="text-sm text-indigo-500">Status: <span class="font-medium capitalize">{{ token.status || 'Pending' }}</span></p>
          <div v-if="isToday(token.date)">
            <p v-if="queueInfo[token.hospital_id] && queueInfo[token.hospital_id].running_token" class="text-sm text-green-600">
              Currently Running: Token #{{ queueInfo[token.hospital_id].running_token.token_number }} at {{ queueInfo[token.hospital_id].running_token.time_slot }}
            </p>
            <p v-if="tokenPosition[token.token_number]" class="text-sm text-blue-600">
              {{ tokenPosition[token.token_number].ahead }} tokens ahead — Estimated time: {{ tokenPosition[token.token_number].estimated_time }}
            </p>
          </div>
        </div>
      </div>
    </div>

    <!-- No Tokens -->
    <div v-if="tokens.length === 0" class="text-center mt-8">
      <p class="text-indigo-600 text-lg">You haven’t booked any tokens yet.</p>
    </div>
  </div>
</template>

<script>
import api from "../axios"
import { useAuthStore } from "../store/auth"

export default {
  data() {
    return {
      tokens: [],
      queueInfo: {},
      tokenPosition: {}
    }
  },
  setup() {
    const authStore = useAuthStore()
    return { authStore }
  },
  computed: {
    normalTokens() {
      return this.tokens.filter(token => token.slot_type === 'normal').sort((a, b) => a.token_number - b.token_number)
    },
    scheduledTokens() {
      return this.tokens.filter(token => token.slot_type === 'scheduled').sort((a, b) => a.token_number - b.token_number)
    }
  },
  async created() {
    try {
      const res = await api.get('/patients/my-tokens')
      this.tokens = res.data
      await this.fetchQueueInfo()
    } catch (err) {
      console.error("Error fetching tokens", err)
    }
  },
  methods: {
    isToday(dateStr) {
      const today = new Date().toISOString().split('T')[0]
      return dateStr === today
    },
    formatDate(dateStr) {
      const date = new Date(dateStr)
      return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })
    },
    async fetchQueueInfo() {
      const uniqueHospitalIds = [...new Set(this.tokens.filter(t => this.isToday(t.date)).map(t => t.hospital_id))]
      for (const hospitalId of uniqueHospitalIds) {
        try {
          const res = await api.get(`/hospitals/current-queue/${hospitalId}`)
          this.queueInfo[hospitalId] = res.data
          this.calculatePositions(hospitalId, res.data)
        } catch (err) {
          console.error("Error fetching queue", err)
        }
      }
    },
    calculatePositions(hospitalId, queueData) {
      const runningToken = queueData.running_token
      const upcoming = queueData.upcoming_tokens
      if (runningToken) {
        // Find position of each token
        const allTokens = [runningToken, ...upcoming]
        allTokens.forEach((token, index) => {
          if (index > 0) {
            const ahead = index
            const estimatedMinutes = ahead * 10
            const runningTime = runningToken.time_slot.split(':')
            const runningHour = parseInt(runningTime[0])
            const runningMinute = parseInt(runningTime[1])
            const totalMinutes = runningHour * 60 + runningMinute + estimatedMinutes
            const estHour = Math.floor(totalMinutes / 60)
            const estMinute = totalMinutes % 60
            const estimatedTime = `${estHour.toString().padStart(2, '0')}:${estMinute.toString().padStart(2, '0')}`
            this.tokenPosition[token.token_number] = {
              ahead: ahead,
              estimated_time: estimatedTime
            }
          }
        })
      }
    }
  }
}
</script>
