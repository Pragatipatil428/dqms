<template>
  <div class="min-h-screen bg-gray-50 p-6">
    <h1 class="text-3xl font-extrabold text-center mb-8 text-indigo-700">Patient Dashboard</h1>

    <!-- Hospitals List -->
    <div class="grid md:grid-cols-2 gap-6">
      <div
        v-for="hospital in hospitals"
        :key="hospital.id"
        class="bg-white shadow-lg rounded-2xl p-6 hover:shadow-indigo-300 transition-shadow"
      >
        <h2 class="text-xl font-semibold text-indigo-900 mb-1">{{ hospital.name }}</h2>
        <p class="text-sm text-indigo-600 mb-4">{{ hospital.email }}</p>

        <!-- Queue Selection -->
        <div class="mb-4">
          <label class="inline-flex items-center mr-6 cursor-pointer">
            <input
              type="radio"
              class="form-radio text-indigo-600"
              value="normal"
              v-model="selectedQueue"
            />
            <span class="ml-2 text-indigo-800 font-medium">Normal Queue</span>
          </label>
          <label class="inline-flex items-center cursor-pointer">
            <input
              type="radio"
              class="form-radio text-indigo-600"
              value="scheduled"
              v-model="selectedQueue"
            />
            <span class="ml-2 text-indigo-800 font-medium">Scheduled Queue</span>
          </label>
        </div>

        <!-- Preferred Time Input -->
        <div v-if="selectedQueue === 'scheduled'" class="mb-4">
          <label class="block mb-1 text-indigo-700 font-semibold">Preferred Date and Time</label>
          <input
            type="datetime-local"
            v-model="preferredTime"
            class="border border-indigo-300 rounded-lg px-3 py-2 w-full text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400"
          />
        </div>

        <!-- Request Token Button -->
        <button
          @click="requestToken(hospital.id, selectedQueue)"
          class="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition"
        >
          Request Token
        </button>
      </div>
    </div>

    <!-- Messages -->
    <div v-if="message" class="mt-8 text-center">
      <p
        :class="{
          'text-green-600 font-semibold': message.startsWith('✅'),
          'text-red-600 font-semibold': message.startsWith('❌')
        }"
      >
        {{ message }}
      </p>
    </div>
  </div>
</template>

<script>
import api from '../axios'
import { useAuthStore } from '../store/auth'

export default {
  data() {
    return {
      hospitals: [],
      preferredTime: "",
      message: "",
      selectedQueue: "normal"
    }
  },
  setup() {
    const authStore = useAuthStore()
    return { authStore }
  },
  async created() {
    const res = await api.get('/patients/hospitals')
    this.hospitals = res.data
  },
  methods: {
    async requestToken(hospitalId, type) {
      try {
        const res = await api.post('/patients/request-token', {
          patient_id: this.authStore.user.id, // ✅ dynamic from store
          hospital_id: hospitalId,
          slot_type: type,
          preferred_time: this.preferredTime
        })
        this.message = `✅ ${res.data.message} | Token: ${res.data.token_number}, Time: ${res.data.time_slot}`
      } catch (err) {
        this.message = `❌ ${err.response?.data?.message || 'Error requesting token'}`
      }
    }
  }
}
</script>
