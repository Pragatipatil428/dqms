<template>
  <div class="min-h-screen bg-gray-50 p-6">
    <h1 class="text-3xl font-extrabold text-center mb-8 text-indigo-700">Hospital Dashboard</h1>

    <!-- Normal Token Requests -->
    <div v-if="normalTokens.length > 0" class="mb-8">
      <h2 class="text-2xl font-bold mb-4 text-indigo-800">Normal Token Requests</h2>
      <div class="grid md:grid-cols-2 gap-6">
        <div
          v-for="token in normalTokens"
          :key="token.token_number"
          class="bg-white shadow-lg rounded-2xl p-6 hover:shadow-indigo-300 transition-shadow"
        >
          <h3 class="text-xl font-semibold text-indigo-900 mb-2">Token #{{ token.token_number }}</h3>
          <p class="text-indigo-700 mb-1">
            Patient: <span class="font-medium">{{ token.patient_name }}</span>
          </p>
          <p class="text-indigo-600">Time Slot: {{ token.time_slot }}</p>
        </div>
      </div>
    </div>

    <!-- Scheduled Token Requests -->
    <div v-if="scheduledTokens.length > 0" class="mb-8">
      <h2 class="text-2xl font-bold mb-4 text-indigo-800">Scheduled Token Requests</h2>
      <div class="grid md:grid-cols-2 gap-6">
        <div
          v-for="token in scheduledTokens"
          :key="token.token_number"
          class="bg-white shadow-lg rounded-2xl p-6 hover:shadow-indigo-300 transition-shadow"
        >
          <h3 class="text-xl font-semibold text-indigo-900 mb-2">Token #{{ token.token_number }}</h3>
          <p class="text-indigo-700 mb-1">
            Patient: <span class="font-medium">{{ token.patient_name }}</span>
          </p>
          <p class="text-indigo-600">Time Slot: {{ token.time_slot }}</p>
        </div>
      </div>
    </div>

    <!-- No Requests -->
    <div v-if="tokens.length === 0" class="text-center mt-8">
      <p class="text-indigo-600 text-lg">No token requests for today.</p>
    </div>
  </div>
</template>

<script>
import api from "../axios"
import { useAuthStore } from '../store/auth'

export default {
  data() {
    return { tokens: [] }
  },
  setup() {
    const authStore = useAuthStore()
    return { authStore }
  },
  computed: {
    normalTokens() {
      return this.tokens.filter(token => token.slot_type === 'normal')
    },
    scheduledTokens() {
      return this.tokens.filter(token => token.slot_type === 'scheduled')
    }
  },
  async created() {
    try {
      const res = await api.get(`/hospitals/token-requests/${this.authStore.user.id}`)
      this.tokens = res.data
    } catch (err) {
      console.error("Error fetching tokens", err)
    }
  }
}
</script>
