<template>
  <div class="min-h-screen flex items-center justify-center bg-gray-100">
    <div class="bg-white p-6 rounded-xl shadow-md w-96">
      <h2 class="text-xl font-bold mb-4 text-center">Hospital Signup</h2>
      <form @submit.prevent="signup">
        <input
          type="text"
          v-model="name"
          placeholder="Hospital Name"
          class="border w-full mb-2 p-2 rounded"
          required
        />
        <input
          type="email"
          v-model="email"
          placeholder="Email"
          class="border w-full mb-2 p-2 rounded"
          required
        />
        <input
          type="password"
          v-model="password"
          placeholder="Password"
          class="border w-full mb-2 p-2 rounded"
          required
        />
        <button
          class="bg-green-500 w-full py-2 rounded text-white hover:bg-green-600 transition"
        >
          Signup
        </button>
      </form>
      <p class="text-center mt-2 text-red-500">{{ message }}</p>
    </div>
  </div>
</template>

<script>
import api from "../axios"
import { useRouter } from "vue-router"
import { useAuthStore } from "../store/auth"

export default {
  data() {
    return {
      name: "",
      email: "",
      password: "",
      message: ""
    }
  },
  setup() {
    const router = useRouter()
    const authStore = useAuthStore()
    return { router, authStore }
  },
  methods: {
    async signup() {
      try {
        const res = await api.post("/auth/hospital/signup", {
          name: this.name,
          email: this.email,
          password: this.password
        })
        // store hospital in Pinia
        this.authStore.login({ id: res.data.hospital_id, email: this.email }, "hospital")
        this.router.push("/hospital-dashboard")
      } catch (err) {
        this.message = err.response?.data?.message || "Signup failed"
      }
    }
  }
}
</script>
