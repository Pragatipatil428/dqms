<template>
  <div class="min-h-screen flex items-center justify-center bg-gray-100">
    <div class="bg-white p-6 rounded-xl shadow-md w-96">
      <h2 class="text-xl font-bold mb-4 text-center">Hospital Login</h2>
      <form @submit.prevent="login">
        <input type="email" v-model="email" placeholder="Email" class="border w-full mb-2 p-2 rounded" required />
        <input type="password" v-model="password" placeholder="Password" class="border w-full mb-4 p-2 rounded" required />
        <button class="bg-green-500 w-full py-2 rounded text-white hover:bg-green-600 transition">Login</button>
      </form>
      <p class="text-center mt-2 text-red-500">{{ message }}</p>
    </div>
  </div>
</template>

<script>
import api from '../axios'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../store/auth'

export default {
  data() {
    return {
      email: '',
      password: '',
      message: ''
    }
  },
  setup() {
    const router = useRouter()
    const authStore = useAuthStore()
    return { router, authStore }
  },
  methods: {
    async login() {
      try {
        const res = await api.post('/auth/hospital/login', {
          email: this.email,
          password: this.password
        })
        // save hospital in store with token
        this.authStore.login(res.data.user, 'hospital', res.data.token, 15)
        this.router.push('/hospital-dashboard')
      } catch (err) {
        this.message = err.response?.data?.message || 'Login failed'
      }
    }
  }
}
</script>
