<template>
  <div class="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-6">
    <h1 class="text-4xl font-bold text-blue-600 mb-6">🏥 Smart Hospital Queue</h1>
    <p class="text-gray-700 text-lg mb-10 text-center max-w-xl">
      Manage hospital appointments and tokens efficiently. 
      Patients can book appointments, hospitals can manage queues in real-time.
    </p>

    <!-- Role Selection -->
    <div class="grid md:grid-cols-2 gap-6 w-full max-w-3xl">
      <!-- Patient Card -->
      <div class="bg-white p-6 rounded-xl shadow-md flex flex-col items-center">
        <h2 class="text-2xl font-semibold text-gray-800 mb-3">For Patients</h2>
        <p class="text-gray-600 text-center mb-4">Book appointments or join the hospital queue with ease.</p>
        <div class="flex gap-4">
          <button 
            @click="$router.push('/patient-login')" 
            class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition">
            Login
          </button>
          <button 
            @click="$router.push('/patient-signup')" 
            class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition">
            Signup
          </button>
        </div>
      </div>

      <!-- Hospital Card -->
      <div class="bg-white p-6 rounded-xl shadow-md flex flex-col items-center">
        <h2 class="text-2xl font-semibold text-gray-800 mb-3">For Hospitals</h2>
        <p class="text-gray-600 text-center mb-4">Manage patient requests, approve appointments, and streamline queues.</p>
        <div class="flex gap-4">
          <button 
            @click="$router.push('/hospital-login')" 
            class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition">
            Login
          </button>
          <button 
            @click="$router.push('/hospital-signup')" 
            class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition">
            Signup
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
